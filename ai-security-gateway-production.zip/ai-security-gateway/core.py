import os, time, hashlib, secrets, logging
from datetime import datetime, timedelta, timezone
from collections import defaultdict, deque
import jwt
from fastapi import Header, HTTPException, Request
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker

PREFIX=os.getenv("PRODUCT_PREFIX","STANDALONE").upper()
if "EVERGREEN" in PREFIX:
    raise RuntimeError("PRODUCT_PREFIX cannot use the protected Evergreen namespace")
def config(name,default=""):
    return os.getenv(f"{PREFIX}_{name}",default)
def assert_isolated_resource(value,label):
    protected=("evergreen", "evergreensoftwaresolution.com")
    if any(marker in str(value).lower() for marker in protected):
        raise RuntimeError(f"Isolation guard blocked {label}: an Evergreen resource must not be used by this standalone product")
    return value
def normalize_database_url(value):
    if value.startswith("postgres://"):return value.replace("postgres://","postgresql+psycopg://",1)
    if value.startswith("postgresql://"):return value.replace("postgresql://","postgresql+psycopg://",1)
    return value
DATABASE_URL=normalize_database_url(config("DATABASE_URL","sqlite:///./app.db"))
assert_isolated_resource(DATABASE_URL,"database URL")
connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {}
engine=create_engine(DATABASE_URL,pool_pre_ping=True,connect_args=connect_args)
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
Base=declarative_base()
ENV=config("APP_ENV","development").lower()
SECRET=config("APP_SECRET","")
if ENV=="production" and len(SECRET)<32:
    raise RuntimeError("APP_SECRET must contain at least 32 characters in production")
if not SECRET:
    SECRET="development-only-secret-change-before-production"
    logging.getLogger(__name__).warning("Using development APP_SECRET; never use this value in production")

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True); email=Column(String(320),unique=True,index=True,nullable=False)
    password_hash=Column(String(128),nullable=False); created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

def password_hash(password):
    salt=secrets.token_hex(16); digest=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1).hex()
    return salt+":"+digest
def password_ok(password,stored):
    try:
        salt,digest=stored.split(":",1)
        actual=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1).hex()
        return secrets.compare_digest(actual,digest)
    except Exception:return False
def token(user):
    return jwt.encode({"sub":str(user.id),"email":user.email,"exp":datetime.now(timezone.utc)+timedelta(hours=24)},SECRET,algorithm="HS256")
def current_user(authorization:str|None=Header(None)):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(401,"Authentication required")
    try:data=jwt.decode(authorization[7:],SECRET,algorithms=["HS256"])
    except jwt.PyJWTError:raise HTTPException(401,"Invalid or expired session")
    db=SessionLocal(); user=db.get(User,int(data["sub"])); db.close()
    if not user:raise HTTPException(401,"Account not found")
    return user

_hits=defaultdict(deque)
def rate_limit(request:Request,limit=60,window=60,bucket="general",identity=None):
    forwarded=request.headers.get("x-forwarded-for","").split(",")[0].strip()
    remote=forwarded or (request.client.host if request.client else "unknown")
    key=f"{bucket}:{identity or remote}"; now=time.time(); q=_hits[key]
    while q and q[0]<now-window:q.popleft()
    if len(q)>=limit:raise HTTPException(429,"Rate limit exceeded")
    q.append(now)

async def llm(messages,system="You are a helpful assistant.",temperature=.2):
    import httpx
    key=config("OPENAI_API_KEY"); base=assert_isolated_resource(config("OPENAI_BASE_URL","https://api.openai.com/v1").rstrip("/"),"AI provider URL")
    if not key:raise HTTPException(503,f"{PREFIX}_OPENAI_API_KEY is not configured")
    payload={"model":config("OPENAI_MODEL","gpt-4.1-mini"),"messages":[{"role":"system","content":system}]+messages,"temperature":temperature}
    async with httpx.AsyncClient(timeout=90) as client:
        r=await client.post(base+"/chat/completions",headers={"Authorization":f"Bearer {key}"},json=payload)
    if r.status_code>=400:raise HTTPException(502,"AI provider request failed")
    try:return r.json()["choices"][0]["message"]["content"]
    except (KeyError,IndexError,TypeError,ValueError):raise HTTPException(502,"AI provider returned an unexpected response")

def harden(app):
    @app.middleware("http")
    async def security_headers(request,call_next):
        response=await call_next(request)
        response.headers["X-Content-Type-Options"]="nosniff"
        response.headers["X-Frame-Options"]="DENY"
        response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'"
        response.headers["Cache-Control"]="no-store" if request.url.path.startswith("/api/") else "no-cache"
        return response
