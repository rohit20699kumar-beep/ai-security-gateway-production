# Aegis AI Security Gateway

OpenAI-compatible security proxy for AI applications. It detects common prompt-injection language, credentials and PII; blocks high-risk requests; redacts sensitive values; issues revocable hashed gateway keys; forwards permitted calls; and records tenant-isolated audit events and risk metrics.

## Run

1. Copy `.env.example` to `.env`; set `AEGIS_APP_SECRET` and `AEGIS_OPENAI_API_KEY`.
2. `docker build -t aegis-ai .`
3. `docker run --env-file .env -p 8104:8104 aegis-ai`
4. Create an account, issue a gateway key, and call:

```bash
curl http://localhost:8104/v1/chat/completions -H "X-Gateway-Key: aeg_..." -H "Content-Type: application/json" -d '{"messages":[{"role":"user","content":"Summarise this safe text"}]}'
```

API keys are shown once and only SHA-256 hashes are stored. For Render, use `render.yaml`. Regex controls are a transparent first enforcement layer, not a guarantee against every adversarial input. Enterprise deployment should add a dedicated classifier, per-tenant policies, KMS-managed provider keys, SIEM export, SSO/RBAC, retention rules and human approval workflows.

## Why this product

Agentic AI systems ingest untrusted content and may access tools or private data. This gateway provides a practical choke point for policy enforcement and evidence collection without forcing application teams to rewrite their model integration.

The problem selection is grounded in OWASP's LLM01:2025 Prompt Injection guidance and the NIST AI RMF Generative AI Profile. The implemented controls map to input filtering, sensitive-data handling, least privilege through scoped gateway keys, and auditable risk management. This version does not claim fool-proof prevention; defenses must be tested and updated continuously.
