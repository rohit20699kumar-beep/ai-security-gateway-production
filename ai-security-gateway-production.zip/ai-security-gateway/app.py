import os,re,json,secrets,hashlib,httpx
from datetime import datetime,timezone
from fastapi import FastAPI,Depends,HTTPException,Request,Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel,EmailStr,Field
from sqlalchemy import Column,Integer,String,Text,DateTime,Boolean
from core import Base,engine,SessionLocal,User,password_hash,password_ok,token,current_user,rate_limit,harden,config,assert_isolated_resource

class ApiKey(Base):
 __tablename__="api_keys";id=Column(Integer,primary_key=True);user_id=Column(Integer,index=True);name=Column(String(100));prefix=Column(String(20));key_hash=Column(String(64),unique=True);active=Column(Boolean,default=True);created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Event(Base):
 __tablename__="security_events";id=Column(Integer,primary_key=True);user_id=Column(Integer,index=True);request_id=Column(String(40),index=True);risk_score=Column(Integer);decision=Column(String(20));findings=Column(Text);redacted_input=Column(Text);provider=Column(String(50));model=Column(String(100));created_at=Column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
Base.metadata.create_all(engine)
app=FastAPI(title="Aegis AI Security Gateway",version="1.1.0");harden(app);app.mount("/static",StaticFiles(directory="static"),name="static")
class Auth(BaseModel):email:EmailStr;password:str=Field(min_length=8,max_length=128)
class KeyName(BaseModel):name:str=Field(min_length=2,max_length=100)
class GatewayRequest(BaseModel):messages:list[dict];model:str|None=None;temperature:float=0.2
PATTERNS={
 "prompt_injection":[r"ignore (all|any|the|previous|prior).{0,20}(instruction|prompt)",r"reveal.{0,20}(system prompt|developer message)",r"you are now (?:in )?(?:developer|admin|root) mode",r"bypass.{0,20}(safety|policy|guardrail)"],
 "secret":[r"\bsk-[A-Za-z0-9_-]{16,}\b",r"(?i)(api[_ -]?key|password|secret|token)\s*[:=]\s*[^\s,;]{8,}"],
 "pii":[r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",r"\b(?:\+?\d[\d -]{8,}\d)\b",r"\b\d{3}-\d{2}-\d{4}\b"]}
def scan(text):
 findings=[];score=0;redacted=text
 weights={"prompt_injection":70,"secret":60,"pii":25}
 for kind,patterns in PATTERNS.items():
  for pattern in patterns:
   matches=list(re.finditer(pattern,text,re.I|re.S))
   if matches:
    findings.append({"type":kind,"count":len(matches),"severity":"critical" if weights[kind]>=60 else "medium"});score=max(score,weights[kind]);redacted=re.sub(pattern,f"[{kind.upper()}_REDACTED]",redacted,flags=re.I|re.S)
 return min(100,score+max(0,len(findings)-1)*10),findings,redacted
def gateway_user(x_gateway_key:str|None=Header(None)):
 if not x_gateway_key:raise HTTPException(401,"X-Gateway-Key required")
 h=hashlib.sha256(x_gateway_key.encode()).hexdigest();db=SessionLocal();k=db.query(ApiKey).filter_by(key_hash=h,active=True).first();u=db.get(User,k.user_id) if k else None;db.close()
 if not u:raise HTTPException(401,"Invalid gateway key")
 return u
@app.get("/")
def home():return FileResponse("static/index.html")
@app.get("/health")
def health():return {"status":"ok","service":"Aegis AI Security Gateway"}
@app.post("/api/register")
def register(a:Auth,request:Request):
 rate_limit(request,5,300,"register")
 db=SessionLocal()
 if db.query(User).filter(User.email==a.email.lower()).first():db.close();raise HTTPException(409,"Email exists")
 u=User(email=a.email.lower(),password_hash=password_hash(a.password));db.add(u);db.commit();db.refresh(u);t=token(u);db.close();return {"token":t}
@app.post("/api/login")
def login(a:Auth,request:Request):
 rate_limit(request,10,300,"login",a.email.lower())
 db=SessionLocal();u=db.query(User).filter(User.email==a.email.lower()).first()
 if not u or not password_ok(a.password,u.password_hash):db.close();raise HTTPException(401,"Invalid credentials")
 t=token(u);db.close();return {"token":t}
@app.post("/api/keys")
def create_key(body:KeyName,u=Depends(current_user)):
 raw="aeg_"+secrets.token_urlsafe(32);db=SessionLocal();k=ApiKey(user_id=u.id,name=body.name,prefix=raw[:12],key_hash=hashlib.sha256(raw.encode()).hexdigest());db.add(k);db.commit();db.refresh(k);db.close();return {"id":k.id,"key":raw,"warning":"Copy now; it cannot be shown again."}
@app.get("/api/keys")
def keys(u=Depends(current_user)):
 db=SessionLocal();rows=db.query(ApiKey).filter_by(user_id=u.id).all();out=[{"id":x.id,"name":x.name,"prefix":x.prefix,"active":x.active,"created_at":x.created_at} for x in rows];db.close();return out
@app.delete("/api/keys/{kid}")
def revoke(kid:int,u=Depends(current_user)):
 db=SessionLocal();k=db.query(ApiKey).filter_by(id=kid,user_id=u.id).first()
 if not k:db.close();raise HTTPException(404,"Key not found")
 k.active=False;db.commit();db.close();return {"revoked":True}
@app.post("/v1/chat/completions")
async def gateway(body:GatewayRequest,request:Request,u=Depends(gateway_user)):
 rate_limit(request,60,60,"gateway",u.id);request_id=secrets.token_hex(12);texts=[]
 if not body.messages or len(body.messages)>50:raise HTTPException(422,"messages must contain 1 to 50 items")
 for m in body.messages:
  if m.get("role") not in {"system","user","assistant","tool"}:raise HTTPException(422,"Invalid message role")
  c=m.get("content","");texts.append(c if isinstance(c,str) else json.dumps(c))
 if sum(map(len,texts))>100000:raise HTTPException(413,"Message content exceeds 100,000 characters")
 allowed_models={x.strip() for x in config("ALLOWED_MODELS",config("OPENAI_MODEL","gpt-4.1-mini")).split(",") if x.strip()};selected=body.model or config("OPENAI_MODEL","gpt-4.1-mini")
 if selected not in allowed_models:raise HTTPException(422,"Requested model is not allowed")
 score,findings,redacted=scan("\n".join(texts));decision="blocked" if score>=70 else "redacted" if findings else "allowed"
 retained=redacted[:20000] if config("RETAIN_REDACTED_INPUT","false").lower()=="true" else ""
 db=SessionLocal();event=Event(user_id=u.id,request_id=request_id,risk_score=score,decision=decision,findings=json.dumps(findings),redacted_input=retained,provider="openai",model=selected);db.add(event);db.commit();db.refresh(event)
 if decision=="blocked":db.close();raise HTTPException(403,{"request_id":request_id,"decision":decision,"risk_score":score,"findings":findings})
 key=config("OPENAI_API_KEY")
 if not key:db.close();raise HTTPException(503,"AEGIS_OPENAI_API_KEY not configured")
 clean=[]
 for m in body.messages:
  c=m.get("content","");_,_,safe=scan(c if isinstance(c,str) else json.dumps(c));clean.append({"role":m.get("role","user"),"content":safe})
 payload={"model":selected,"messages":clean,"temperature":max(0,min(2,body.temperature))}
 base=assert_isolated_resource(config("OPENAI_BASE_URL","https://api.openai.com/v1").rstrip("/"),"AI provider URL")
 async with httpx.AsyncClient(timeout=90) as client:r=await client.post(base+"/chat/completions",headers={"Authorization":f"Bearer {key}"},json=payload)
 if r.status_code>=400:event.decision="upstream_error";db.commit();db.close();raise HTTPException(502,"Upstream AI provider failed")
 try:data=r.json();output=data["choices"][0]["message"].get("content","")
 except (ValueError,KeyError,IndexError,TypeError):db.close();raise HTTPException(502,"Upstream AI provider returned an unexpected response")
 output_score,output_findings,safe_output=scan(output or "")
 if output_findings:
  data["choices"][0]["message"]["content"]=safe_output;findings=findings+[{**x,"type":"output_"+x["type"]} for x in output_findings];event.findings=json.dumps(findings);event.risk_score=max(score,output_score);event.decision="output_blocked" if output_score>=70 else "output_redacted";decision=event.decision
 db.commit();db.close();data["security"]={"request_id":request_id,"decision":decision,"risk_score":max(score,output_score),"findings":findings};return data
@app.get("/api/events")
def events(u=Depends(current_user)):
 db=SessionLocal();rows=db.query(Event).filter_by(user_id=u.id).order_by(Event.id.desc()).limit(200).all();out=[{"request_id":x.request_id,"risk_score":x.risk_score,"decision":x.decision,"findings":json.loads(x.findings),"model":x.model,"created_at":x.created_at} for x in rows];db.close();return out
@app.get("/api/dashboard")
def dashboard(u=Depends(current_user)):
 db=SessionLocal();q=db.query(Event).filter_by(user_id=u.id);out={"total":q.count(),"blocked":q.filter(Event.decision.in_(["blocked","output_blocked"])).count(),"redacted":q.filter(Event.decision.in_(["redacted","output_redacted"])).count(),"allowed":q.filter_by(decision="allowed").count()};db.close();return out
