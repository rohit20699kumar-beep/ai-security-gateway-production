# Production handoff checklist

- Replace all example secrets and use managed secret storage.
- Use PostgreSQL with automated backups and test restoration.
- Configure HTTPS, a custom domain, health monitoring and error alerting.
- Add email verification, password reset, billing/quotas and abuse controls before public self-service sales.
- Publish privacy, terms, refund, AI-use and data-retention policies.
- Configure model spend limits and review prompt/output logs without retaining unnecessary personal data.
- Run dependency, container and application security scans in CI.
- Complete load, accessibility, browser and user-acceptance testing for the intended customer volume.

The repository contains production-oriented application code and deployment assets. “Ready to sell” still requires the operator's provider accounts, policies, business identity, support process and final production acceptance testing.
