# Evergreen isolation guarantee

This package is a standalone product and is not an Evergreen module.

## Enforced boundaries

- It has its own Render web-service name and its own PostgreSQL database name.
- It uses product-prefixed environment variables; generic Evergreen environment variables are ignored.
- It has no Firebase project, Firebase Admin SDK, Evergreen authentication, Razorpay integration, Evergreen API route, Evergreen domain, GitHub remote or deployment identifier.
- It uses a distinct local port so all four products can run without colliding with Evergreen or one another.
- A runtime isolation guard refuses any database URL or AI-provider URL containing an Evergreen resource name/domain.
- The application only creates tables inside the database explicitly supplied through its own prefixed database variable.

## Safe deployment rule

Deploy this ZIP as a new Render Blueprint/service. Never upload it over the Evergreen repository, never attach `evergreen-staging-db`, and never reuse Evergreen's application secret. Using its bundled `render.yaml` creates the intended separate service and database.

No software can prevent a hosting administrator from manually replacing files or deliberately pasting another database URL. The runtime guard prevents the most dangerous accidental Evergreen connection, while the remaining boundary depends on deploying it as the separate service described above.
